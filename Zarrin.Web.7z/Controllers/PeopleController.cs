﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Zarrin.Web.Controllers
{
    public class Person
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

    }
    public class PeopleController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Indexx()
        {
            return View();
        }
        [HttpGet]
        public JsonResult GetAllPeople()
        {
            var people = new List<Person>
            {
                new Person{Id=1, FirstName="hadi",LastName="hoseini"},
                new Person{Id=2, FirstName="parvin",LastName="varmezyar"}

            };
            return Json(new { data= people });
        }
    }
}